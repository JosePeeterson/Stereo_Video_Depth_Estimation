clear;
clc;
close all;
%% input parameters here
addpath('.\GCMex')
addpath('.\Pictures')
% max_disparity means there are 65 levels of depths or 65 labels
max_disparity = 65;
left_img = double(imread('.\Pictures\im2.png'));
right_img = double(imread('.\Pictures\im6.png'));
true_depth_map = rgb2gray(im2double(imread('.\Pictures\depth.png')));
%%

% Depth and Disparity are used interchangeably.
% for calculating error between ground truth and calculated depth map.
true_depth_map = resample(true_depth_map',450,892);
true_depth_map = resample(true_depth_map',375,748);

[Height, Width, ~] = size(left_img);
Total_pxl=Height*Width;

% reshape image to index using the pixel number instead of x and y
temp_left=reshape(left_img,1,Total_pxl,3);
temp_right=reshape(right_img,1,Total_pxl,3);

% reshape 2d image into 1d array. index using 1 to total number of pixels
% in the 2d image. In addition, pxl_x array contains with 4 redundant pixel
% indices (node) to align with 4 neighbouring pixels node+/-(1/height).
% size of pxl_x and Nei_pxl_y is 1 x 4*Total_num_pixels
%pxl_x = zeros(1,2070600);
%Nei_pxl_y = zeros(1,2070600);
i=1;
for x = 1:Width
    for y = 1:Height
        node = (x-1)*Height + y;
        if y < Height
            pxl_x(i)=node;
            Nei_pxl_y(i)=node+1;
            i=i+1;
        end
        if y > 1
            pxl_x(i)=node;
            Nei_pxl_y(i)=node-1;
            i=i+1;
        end
        if x < Width
            pxl_x(i)=node;
            Nei_pxl_y(i)=node+Height;
            i=i+1;
        end
        if x > 1
            pxl_x(i)=node;
            Nei_pxl_y(i)=node-Height;
            i=i+1;
        end
    end
end

% For rectified images, the ys or the rows are already aligned.
% In order to find the unary data terms, we shift the pixel values by 
% vertical strips/columns which are multiples of height in the right image.
% then compare this shifted image with the unshifted left image. when any
% pixel in the shifted image aligns with the left image in the correct 
% column the differnce in pixel intesity values is minimal.
% This shift is the disparity for that particular pixel.
for disp_level=1:max_disparity
    vert_strips=disp_level*Height;
    unary(disp_level,:)=sum(abs(cat(2,zeros(1,vert_strips,3),temp_right(1,1:Total_pxl-vert_strips,:))-temp_left),3)./3;
end

% For each pixel we find the shift that gives the minimum difference in
% pixel intensity values and take it as disparity.
[~, segclass] = min(unary); 
segclass = segclass' - 1;

% As we are dealing with multilabel case for pairwise neighbours we create
% a 2d array of all the possible depths for current pixel and its neighbour
% The cost is directly proportional to squared distance in terms of disparity
% between neighbouring pixels.
% This term promotes smoothness in disparity for neighbouring pixels.
[x, y] = meshgrid(1:max_disparity, 1:max_disparity);
labelcost = log(1+((x - y).^2)./2);

% lambda is a weighting/regularizing term that trades observation to 
% smoothness between neighbours. After checking from 1 to 13 it was found
% minimum error lambda lies between 1 and 10
% GCMex performs graph cut energy minimisation and returns disparity
% value(labels) for each pixel.
for lamb=1:9
    pairwise=sparse(pxl_x,Nei_pxl_y,lamb);
    [label, ~, ~] = GCMex(segclass, single(unary), pairwise, single(labelcost),1);
    label = reshape(label,Height,Width);
    calc_depth_map = mat2gray(label);
    % from experiment lambda = 6 gives the minimum error result to ground
    % truth 
    if lamb == 6
        figure(1)
        imshow(calc_depth_map)
        xlabel('Lambda=6')
        figure(2)
        imshow(true_depth_map)
        xlabel('Original, ground truth depth map')
    end
    difference(lamb) = sum(sum((abs(calc_depth_map-true_depth_map))))./Total_pxl;
end
% plot of error between calculated depth and ground truth depth vs. lambda
figure(3)
plot(difference)
xlabel('Lambda value')
ylabel('(L1__norm) difference')
