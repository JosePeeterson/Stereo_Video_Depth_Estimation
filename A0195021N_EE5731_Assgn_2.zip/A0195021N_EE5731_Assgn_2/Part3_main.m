clear;
clc;
close all;
%% input parameters here
addpath('.\GCMex')
addpath('.\Pictures')
left_img=double(imread('.\Pictures\test00.jpg'));
right_img=double(imread('.\Pictures\test09.jpg'));
temp_cam_param=fopen('.\Camera_params\two_cam_P_matrices.txt','r');
cam_param = fscanf(temp_cam_param, '%f %f %f', [3,Inf]);
fclose(temp_cam_param);

disp_min=0; % minimum disparity 
disp_interval=1e-4; % disparity levels or steps
disp_max=0.01; % maximum disparity 
max_disp_lvl=1+(disp_max-disp_min)./disp_interval; % max_disp_lvl means there are 101 levels of depths or 101 labels
n_Eta=0.05.*(disp_max-disp_min); % threshold value in smoothness cost 
e_Epsilon=50;%contrast sensitiviy
W_S=20./(disp_max-disp_min); %smoothness strength
SIGMA_C=10; % controls the shape of our differentiable robust function
%%

[Height, Width, ~] = size(left_img);
Total_pxl=Height*Width;
% reshape image to index using the pixel number instead of x and y
temp_left=reshape(left_img,1,Total_pxl,3);

% extract camera parameters including intrinsic (k) and extrinsic (r and t)
% for the two views.
Int_k_1=cam_param(:,1:3)';
Ext_r_1=cam_param(:,4:6)';
Ext_t_1=cam_param(:,7);
Int_k_2=cam_param(:,8:10)';
Ext_r_2=cam_param(:,11:13)';
Ext_t_2=cam_param(:,14);

% reshape 2d image into 1d array. index using 1 to total number of pixels
% in the 2d image. In addition, pxl_x array contains with 4 redundant pixel
% indices (node) to align with 4 neighbouring pixels node+/-(1/height).
% size of pxl_x and Nei_pxl_y is 1 x 4*Total_num_pixels
pxl_x = zeros(1,2070600);
Nei_pxl_y = zeros(1,2070600);
i=1;
for x_lbl = 1:Width
    for y_lbl = 1:Height
        node = (x_lbl-1)*Height + y_lbl;
        if y_lbl < Height
            pxl_x(i)=node;
            Nei_pxl_y(i)=node+1;
            i=i+1;
        end
        if y_lbl > 1
            pxl_x(i)=node;
            Nei_pxl_y(i)=node-1;
            i=i+1;
        end
        if x_lbl < Width
            pxl_x(i)=node;
            Nei_pxl_y(i)=node+Height;
            i=i+1;
        end
        if x_lbl > 1
            pxl_x(i)=node;
            Nei_pxl_y(i)=node-Height;
            i=i+1;
        end
    end
end

% Intensity change term from below equation 4
Intensity_chg=1./(sqrt(sum((temp_left(1,pxl_x,:)-temp_left(1,Nei_pxl_y,:)).^2,3))+e_Epsilon);
% Intensity change term from below equation 4
neigh_Intensity_chg=sparse(pxl_x,Nei_pxl_y,Intensity_chg);

% Number of neighbours is |N(x)| term from below equation 4
% no. of neighbours at pixel location. corner lcoations have only 2 neighbours
% edge locations have 3 neighbours and locations in the middle have 4
% neighbours
neigh_num=4.*ones(Height,Width);
neigh_num(:,1)=3;
neigh_num(:,end)=3;
neigh_num(1,:)=3;
neigh_num(end,:)=3;
neigh_num(1,1)=2;
neigh_num(1,end)=2;
neigh_num(end,1)=2;
neigh_num(end,end)=2;
neigh_num=reshape(neigh_num,1,Total_pxl);

% both the unary and pairwise terms are both functions of all the disparity
% values. they are initialized using all disparity values for all the
% pixles. The min-cut algorithm associates each pixel to the correct
% disparity value.

% normalization factor below equation 4
norm_factor=neigh_num./full(sum(neigh_Intensity_chg));
% lambda from below equation 4
lamb=W_S.*Intensity_chg.*norm_factor(pxl_x);
pairwise=sparse(pxl_x,Nei_pxl_y,lamb);

% robust function
[x_lbl, y_lbl] = meshgrid(1:max_disp_lvl, 1:max_disp_lvl);
labelcost=min(disp_interval.*abs(x_lbl-y_lbl), n_Eta);

[coord_x,coord_y]=meshgrid(1:Width,1:Height);
% left_pxl_loc is every pixel coordinate in  homogeneous coordinates (incl. ones(1,Total_pxls))
left_pxl_loc=[coord_x(:)';coord_y(:)';ones(1,Total_pxl)];
left_pix_vals=impixel(left_img,left_pxl_loc(1,:),left_pxl_loc(2,:));
unary = zeros(101,518400);
for disp=1:max_disp_lvl
    % find corresponding pixel coordinates for all disparity values from
    % disp_min to disp_max in steps of disp_interval (equation 6)
    right_pxl_loc=Int_k_2*Ext_r_2'*Ext_r_1/Int_k_1*left_pxl_loc+(Int_k_2*Ext_r_2'*(Ext_t_1 - Ext_t_2).*disp_interval.*(disp-1));
    right_pxl_loc=round(right_pxl_loc./right_pxl_loc(3,:));
    right_pix_vals=impixel(right_img, right_pxl_loc(1,:), right_pxl_loc(2,:));
    right_pix_vals(isnan(right_pix_vals))=0;
    % equation 2 for all the pixels at each disparity till max_disp_lvl
    unary(disp,:)=(SIGMA_C./(SIGMA_C+sqrt(sum((left_pix_vals-right_pix_vals).^2,2))))';
end
% data term of equation 3
unary=1-(unary./max(unary));
[~,segclass] = min(unary); 
segclass=segclass-1;

% GCMex performs graph cut energy minimisation and returns disparity
% value(labels) for each pixel.
[label, ~, ~] = GCMex(segclass, single(unary), pairwise, single(labelcost),1);
label=reshape(label,Height,Width);
calc_depth_map=mat2gray(label);
imshow(calc_depth_map)

