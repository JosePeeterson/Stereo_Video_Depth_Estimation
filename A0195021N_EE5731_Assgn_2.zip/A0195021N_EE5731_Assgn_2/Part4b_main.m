clear;
clc;
close all;
%% input parameters here
addpath('.\GCMex')
addpath('.\Video')
addpath('.\Part4a_depth_maps')
addpath('.\Part4b_depth_maps')
left_img = double(imread('.\Video\test0000.jpg'));
temp_cam_param = fopen('.\Camera_params\vid_P_matrices.txt','r');
cam_param = fscanf(temp_cam_param,'%f %f %f',[3,Inf]);
fclose(temp_cam_param);

disp_min=0;% minimum disparity 
disp_interval=1e-4;% disparity levels or steps
disp_max=1e-2;% maximum disparity 
max_disp_lvl=1+(disp_max-disp_min)./disp_interval;% max_disp_lvl means there are 101 levels of depths or 101 labels
n_Eta=0.05.*(disp_max-disp_min);% threshold value in smoothness cost 
e_Epsilon=50;%contrast sensitiviy
W_S=10./(disp_max-disp_min);%smoothness strength
SIGMA_C=10;% controls the shape of our differentiable robust function
SIGMA_D=2.5; % standard deviation of gaussian geometric coherance term
num_neigh_frms=3;% process 3 images before middle frame and 3 images after middle frame
Tot_vid_frms=20;%total video frames is no.of depth maps in part4a_dpth_maps - 3 (> 18 and < 141)
iterations=2;
%%

[Height,Weight,~]=size(left_img);
Total_pxl=Height*Weight;

% reshape 2d image into 1d array. index using 1 to total number of pixels
% in the 2d image. In addition, pxl_x array contains with 4 redundant pixel
% indices (node) to align with 4 neighbouring pixels node+/-(1/height).
% size of pxl_x and Nei_pxl_y is 1 x 4*Total_num_pixels
pxl_x = zeros(1,2070600);
Nei_pxl_y = zeros(1,2070600);
i = 1;
for x = 1:Weight
    for y = 1:Height
        node = (x-1)*Height + y;
        if y < Height
            pxl_x(i) = node;
            Nei_pxl_y(i) = node + 1;
            i = i + 1;
        end
        if y>1
            pxl_x(i)=node;
            Nei_pxl_y(i)=node-1;
            i = i + 1;
        end
        if x < Weight
            pxl_x(i) = node;
            Nei_pxl_y(i) = node + Height;
            i = i + 1;
        end
        if x > 1
            pxl_x(i) = node;
            Nei_pxl_y(i) = node - Height;
            i = i + 1;
        end
    end
end

% Number of neighbours is |N(x)| term from below equation 4
% no. of neighbours at pixel location. corner lcoations have only 2 neighbours
% edge locations have 3 neighbours and locations in the middle have 4
% neighbours
neigh_num = 4.*ones(Height,Weight);
neigh_num(:,1) = 3;
neigh_num(:,end) = 3;
neigh_num(1,:) = 3;
neigh_num(end,:) = 3;
neigh_num(1,1) = 2;
neigh_num(1,end) = 2;
neigh_num(end,1) = 2;
neigh_num(end,end) = 2;
neigh_num = reshape(neigh_num,1,Total_pxl);

% robust function
[x_lbl,y_lbl] = meshgrid(1:max_disp_lvl,1:max_disp_lvl);
labelcost = min(disp_interval.*abs(x_lbl-y_lbl), n_Eta);

[coord_x,coord_y] = meshgrid(1:Weight,1:Height);
% middle frame pxl location/coordinates
mid_pxl_loc = [coord_x(:)';coord_y(:)';ones(1,Total_pxl)];

% iterative optimisation
for k = 1:iterations
    if k == 1
        file_root = '.\Part4a_depth_maps';
        first_neigh = num_neigh_frms*2;
    else
        file_root = '.\Part4b_depth_maps\Iteration_1';
        first_neigh = num_neigh_frms*3;
    end
    % frames chosen so that there are 3 frames before and after chosen frame
    for f = first_neigh:Tot_vid_frms-first_neigh
        temp_mid_image = double(imread(['.\Video\test',sprintf('%04d',f),'.jpg']));
        % middle frame to which we want to find didsparity map.
        mid_frm = reshape(temp_mid_image,1,Total_pxl,3);
        
        % choosing camera parameters for the correct frame
        n = f*7;
        mid_frm_K = cam_param(:,1+n:3+n)';
        mid_frm_R = cam_param(:,4+n:6+n)';
        mid_frm_T = cam_param(:,7+n);
        
        % smoothness term setup
        % Intensity change term from below equation 4
        Intensity_chg = 1./(sqrt(sum((mid_frm(1,pxl_x,:)-mid_frm(1,Nei_pxl_y,:)).^2,3))+e_Epsilon);
        neigh_Intensity_chg = sparse(pxl_x,Nei_pxl_y,Intensity_chg);
        % normalization factor below equation 4
        norm_factor = neigh_num./full(sum(neigh_Intensity_chg));
        % lambda from below equation 4
        lamb = W_S.*Intensity_chg.*norm_factor(pxl_x);
        pairwise = sparse(pxl_x,Nei_pxl_y,lamb);
        
        Lik_tot = zeros(max_disp_lvl,Total_pxl);
        % data term setup
        for frm = [f-3,f-2,f-1,f+1,f+2,f+3]
        neigh_frm = double(imread(['.\Video\test',sprintf('%04d',frm),'.jpg']));
        % working with depth map instead of images.
        neigh_disp_map = getfield(load([file_root,'\test',sprintf('%04d',frm),'.mat']),'label');
        
        % neghbouring frame camera parameters
        n = frm*7;
        neigh_frm_K = cam_param(:,1+n:3+n)';
        neigh_frm_R = cam_param(:,4+n:6+n)';
        neigh_frm_T = cam_param(:,7+n);

        mid_pix_vals=impixel(temp_mid_image,mid_pxl_loc(1,:),mid_pxl_loc(2,:));
        Lik_tot_temp=zeros(max_disp_lvl,Total_pxl);
            for disp=1:max_disp_lvl
                % find corresponding pixel coordinates for all disparity values from
                % disp_min to disp_max in steps of disp_interval (equation 6)
                neigh_pxl_loc=neigh_frm_K*neigh_frm_R'*mid_frm_R/mid_frm_K*mid_pxl_loc+neigh_frm_K*neigh_frm_R'*(mid_frm_T-neigh_frm_T).*disp_interval.*(disp-1);
                neigh_pxl_loc=round(neigh_pxl_loc./neigh_pxl_loc(3,:));
                nei_pixl_vals=impixel(neigh_frm, neigh_pxl_loc(1,:), neigh_pxl_loc(2,:));
                nei_pixl_vals(isnan(nei_pixl_vals))=0;
                pc_tprime=(SIGMA_C./(SIGMA_C+sqrt(sum((mid_pix_vals-nei_pixl_vals).^2,2))))';
    
                neigh_pxl_loc=[min(max(neigh_pxl_loc(1,:),1),Weight);min(max(neigh_pxl_loc(2,:),1),Height);ones(1,Total_pxl)];
                trans_loc=sub2ind([Height,Weight],neigh_pxl_loc(2,:),neigh_pxl_loc(1,:));
                % setup for equation 8
                loc_n2c=mid_frm_K*mid_frm_R'*neigh_frm_R/neigh_frm_K*neigh_pxl_loc+mid_frm_K*mid_frm_R'*(neigh_frm_T-mid_frm_T).*(neigh_disp_map(trans_loc)-1).*disp_interval;
                loc_n2c=round(loc_n2c./loc_n2c(3,:));
                pv_tprime=exp(-sum((loc_n2c(1:2,:)-mid_pxl_loc(1:2,:)).^2)./(2.*SIGMA_D.^2));
                
                % calcualte bundle term of both photo-consistency and
                % geometric coherance.
                % equation 2 for all the pixels at each disparity till max_disp_lvl
                Lik_tot_temp(disp,:)=pc_tprime.*pv_tprime;
            end
            % Likelihood  function above equation 7
            Lik_tot=Lik_tot+Lik_tot_temp;
        end
        % data term of equation 9
        unary=1-Lik_tot./max(Lik_tot);
        [~,segclass] = min(unary); 
        segclass=segclass-1;
        % GCMex performs graph cut energy minimisation and returns disparity
        % value(labels) for each pixel.
        [label,~,~]=GCMex(segclass,single(unary),pairwise,single(labelcost),1);
        label=reshape(label,Height,Weight);
        calc_depth_map=mat2gray(label);
        imwrite(calc_depth_map,['.\Part4b_depth_maps\Iteration_',num2str(k),'\test',sprintf('%04d',f),'.jpg']);
        save(['.\Part4b_depth_maps\Iteration_',num2str(k),'\test',sprintf('%04d',f),'.mat'],'label');
    end
end
