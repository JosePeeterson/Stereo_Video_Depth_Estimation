clc;
clear;
close all;

%% input parameters here
addpath('.\GCMex')
addpath('.\Pictures')
noisy_img = double(imread('.\Pictures\bayes_in.jpg'));
Original_img = double(imread('.\Pictures\bayes_out.jpg'));
%%

[Height,Width,~] = size(noisy_img);
Total_pxl = Height*Width;

source_col = [0,0,255]; % foreground blue
sink_col = [245,210,110]; % background yellow

% unary/data term creation
% find out if a pixel is closer to source or sink color
% pixelwise measure distance to source and sink and average over the 3
% channels
source_dist = (abs(noisy_img(:,:,1)-source_col(1))+abs(noisy_img(:,:,2)-source_col(2))+abs(noisy_img(:,:,3)-source_col(3)))./3;
sink_dist = (abs(noisy_img(:,:,1)-sink_col(1))+abs(noisy_img(:,:,2)-sink_col(2))+abs(noisy_img(:,:,3)-sink_col(3)))./3;
% reshape into a unary array of two 1d source and sink distnace arrays.
unary = [reshape(source_dist,1,Total_pxl);reshape(sink_dist,1,Total_pxl)];
% determine if a pixel belongs to background. segclass is 1 for background
% and 0 for forground
segclass = double(unary(1,:)>=unary(2,:));

% reshape 2d image into 1d array. index using 1 to total number of pixels
% in the 2d image. In addition, pxl_x array contains with 4 redundant pixel
% indices (node) to align with 4 neighbouring pixels node+/-(1/height).
% size of pxl_x and Nei_pxl_y is 1 x 4*Total_num_pixels
i = 1;
for x = 1:Width
    for y = 1:Height
        node = (x-1)*Height+y;
        if y < Height
            pxl_x(i) = node;
            Nei_pxl_y(i) = node+1;
            i = i + 1;
        end
        if y > 1
            pxl_x(i) = node;
            Nei_pxl_y(i) = node-1;
            i = i + 1;
        end
        if x < Width
            pxl_x(i) = node;
            Nei_pxl_y(i) = node + Height;
            i = i + 1;
        end
        if x > 1
            pxl_x(i) = node;
            Nei_pxl_y(i) = node - Height;
            i = i + 1;
        end
    end
end

% for the smoothness cost we define labelcost matrix.
% As it is pairwise labelcost we compare the label of current pixel
% and its neighbour
%                           label of neighbour pxl
%                               source    sink
% label of     :     source  :   0          1
% current pxl  :     sink    :   1          0
% 
% if the labels match cost is 0 otherwise its 1.
labelcost = [0,1;1,0];


% lambda is a weighting/regularizing term that trades observation to 
% smoothness between neighbours. After checking from 1 to 200 it was found
% minimum error lambda lies between 155 and 175
% GCMex performs graph cut energy minimisation and returns denoised labels
% for each pixel.

for Lamb = 155:175
    pairwise = sparse(pxl_x,Nei_pxl_y,Lamb);
    [label,~,~] = GCMex(segclass,single(unary),pairwise,single(labelcost),0);
    label = reshape(label,Height,Width);
    red = label*sink_col(1) + (1-label)*source_col(1);
    green = label*sink_col(2) + (1-label)*source_col(2);
    blue = label*sink_col(3) + (1-label)*source_col(3);
    Denoised_img = cat(3,red,green,blue);
    % from experiment lambda = 167 gives the minimum error result to ground
    % truth 
    if Lamb == 167
        figure(1)
        imshow(uint8(Denoised_img))
        xlabel('Denoised image, best Lambda = 167')
        figure(2)
        imshow(uint8(Original_img))
        xlabel('Original, ground truth image')
    end
    % calculate error using L1 norm
    difference(Lamb) = sum(sum(sum(abs(Denoised_img-Original_img),3)./3))./Total_pxl;
end
% plot of error between denoised image and ground truth vs. lambda
figure(3)
plot(difference)
xlim([155 175])
xlabel('Lambda value')
ylabel('(L1__norm) difference')

